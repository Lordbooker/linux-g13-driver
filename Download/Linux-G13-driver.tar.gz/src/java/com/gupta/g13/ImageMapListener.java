package com.gupta.g13;

public interface ImageMapListener {

	void selected(final Key key);
	
	void mouseover(final Key key);
}
